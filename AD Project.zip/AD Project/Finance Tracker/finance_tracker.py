import streamlit as st
import pandas as pd
import pickle
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from sklearn.ensemble import IsolationForest
import plotly.express as px
import statsmodels.api as sm
from statsmodels.tsa.arima.model import ARIMA
from pmdarima import auto_arima



# Streamlit App Title
st.title("📊 Personal Finance Tracker")

# File Uploader
uploaded_file = st.file_uploader("📂 Upload Your Expense Data (CSV)", type=["csv"])

if uploaded_file is not None:
    # Read the uploaded CSV file
    df = pd.read_csv(uploaded_file)
    # Convert 'Date' column to datetime format
    df["Date"] = pd.to_datetime(df["Date"],format='%d-%m-%Y')
    # Drop rows with missing dates
    df = df.dropna(subset=["Date"])


    # Display Data Preview
    st.subheader("📜 Uploaded Data Preview")
    st.dataframe(df.head())

    # Create Tabs for Different Features
    tab1, tab2, tab3, tab4 = st.tabs(["🏷 Expense Categorization", "📊 Spending Analysis", "📈 Budget Planning", "🔮 Budget Forecasting"])

    # Expense Categorization Tab
    with tab1:
        st.header("🏷 Expense Categorization")
        st.write("This feature categorizes your transactions using an ML model.")
        with open("random_forest_model.pkl", "rb") as f:
            model = pickle.load(f)
        with open("vectorizer.pkl", "rb") as f:
            vectorizer = pickle.load(f)
        with open("category_encoder.pkl", "rb") as f:
            category_encoder = pickle.load(f)

        transaction_mapping = {"debit": 0, "credit": 1}
        description = st.text_input("Enter Transaction Description:")
        amount = st.number_input("Enter Transaction Amount:", min_value=0.0, step=0.01)
        transaction_type = st.selectbox("Transaction Type:", ["debit", "credit"])
        if st.button("Predict Category"):
            if description and amount:
                transformed_desc = vectorizer.transform([description]).toarray()
                transaction_type_num = transaction_mapping[transaction_type]
                input_features = [[*transformed_desc[0], amount, transaction_type_num]]
                predicted_category_num = model.predict(input_features)[0]

                predicted_category = category_encoder.inverse_transform([predicted_category_num])[0]

                st.success(f"Predicted Category: {predicted_category}")
            else:
                st.warning("Please enter all details.")
                    # Spending Analysis Tab



    # Spending Analysis Tab
    with tab2:
        st.header("📊 Spending Analysis")
        st.write("Get insights into your past spending behavior.")
        latest_date = df["Date"].max()
        latest_month = latest_date.to_period("M")  # Latest Year-Month
        num_months = st.slider("Select number of months for analysis", 1, 6, 3)
        valid_months = [(latest_date - pd.DateOffset(months=i)).to_period("M") for i in range(num_months)]
        filtered_df = df[df["Date"].dt.to_period("M").isin(valid_months)]
        st.write("### 📋 Transactions for Selected Months")
        st.dataframe(filtered_df)


        latest_month = df["Date"].dt.strftime("%Y-%m").max()
        latest_month = pd.to_datetime(latest_month)
        start_date = latest_month - pd.DateOffset(months=num_months - 1)
        filtered_df = df[df["Date"] >= start_date]
        total_expense = filtered_df["Amount"].sum()
        monthly_expense = filtered_df.groupby(filtered_df["Date"].dt.strftime("%Y-%m"))["Amount"].sum()
        st.subheader(f"Expense Summary for Last {num_months} Month(s)")
        st.write(f"**Total Expense:** ₹{total_expense:.2f}")
        st.write("### Monthly Expense Breakdown")
        st.dataframe(monthly_expense.reset_index().rename(columns={"Date": "Month", "Amount": "Total Expense"}))
        
        #Pie chart
        category_expense = filtered_df.groupby("Category")["Amount"].sum()
        colors = ['#0D47A1', '#1565C0', '#1976D2', '#1E88E5', '#2196F3', '#42A5F5', '#64B5F6', '#90CAF9']
        fig, ax = plt.subplots()
        ax.pie(category_expense, labels=category_expense.index, autopct='%1.1f%%', startangle=140, colors=colors)
        font_prop = fm.FontProperties(fname=fm.findSystemFonts(fontpaths=None, fontext='ttf')[0], size=14, weight='bold')

        ax.set_title(f"Category-wise Spending for Last {num_months} Month(s)",fontproperties=font_prop, pad=20)
        st.pyplot(fig)

        #Category wise spending
        category_breakdown = filtered_df.groupby("Category")["Amount"].sum().reset_index()
        category_breakdown = category_breakdown.sort_values(by="Amount", ascending=False)
        category_breakdown["Amount"] = category_breakdown["Amount"].apply(lambda x: f"₹{x:,.2f}")
        st.write(f"### Category-wise Spending Breakdown for Last {num_months} Month(s)")
        st.dataframe(category_breakdown, use_container_width=True)
        
        #Anomaly Detection using Isolation Forest
        # Prepare data for anomaly detection (group by category and compute statistics)
        category_stats = filtered_df.groupby("Category")["Amount"].agg(["mean", "std"]).reset_index()
        df_anomaly = filtered_df.merge(category_stats, on="Category", how="left")
        iso_forest = IsolationForest(contamination=0.05, random_state=42)  # 5% anomalies
        df_anomaly["Anomaly"] = iso_forest.fit_predict(df_anomaly[["Amount"]])  
        # Function to generate explanations for anomalies
        def generate_explanation(row):
            if row["Anomaly"] == -1:
                category_mean = row["mean"]
                amount = row["Amount"]
                deviation = ((amount - category_mean) / category_mean) * 100  

                if deviation > 0:
                    return f"Your expense in '{row['Category']}' is {deviation:.2f}% higher than the usual trend."
                else:
                    return f"Your expense in '{row['Category']}' is {-deviation:.2f}% lower than the usual trend."
            else:
                return "Normal"

        # Apply function to add explanation column
        df_anomaly["Explanation"] = df_anomaly.apply(generate_explanation, axis=1)

        # Filter anomalies for display
        anomalies_df = df_anomaly[df_anomaly["Anomaly"] == -1]
        st.write("### 🚨 Detected Anomalies in Spending")
        st.dataframe(anomalies_df[["Date", "Category", "Amount", "Explanation"]], use_container_width=True)

        #Anomaly graph
                
        fig, ax = plt.subplots(figsize=(10, 5))

        # Plot normal transactions
        ax.plot(df_anomaly["Date"], df_anomaly["Amount"], label="Normal Transactions", color="blue", alpha=0.5)

        # Plot anomalies in red
        ax.scatter(anomalies_df["Date"], anomalies_df["Amount"], color="red", label="Anomalies", zorder=2)

        ax.set_title("Spending Trend with Anomalies")
        ax.set_xlabel("Date")
        ax.set_ylabel("Amount Spent")
        ax.legend()

        st.pyplot(fig)




    # Budget Planning Tab
    with tab3:
        st.header("📈 Budget Planning")
        st.write("Plan your budget for different categories.")
        categories = df["Category"].unique()
        
        # User inputs budget in the main section (not sidebar)
        total_budget = st.number_input("Enter your total monthly budget (₹):",min_value=0,  placeholder="%.2f")
        if not total_budget:
            total_budget = 0

        category_spending = df.groupby("Category")["Amount"].sum()
        total_spent = category_spending.sum()
        suggested_budget = (category_spending / total_spent) * total_budget

        user_budget = {}
        for category in categories:
            budget_value = st.number_input(
                f"Budget for {category} (₹):", min_value=0, placeholder="%.2f"
            )
            user_budget[category] = budget_value if budget_value else 0 

        st.write("### Your Selected Budget Plan")
        st.write(f"**Total Budget:** ₹{total_budget}")
        st.write("#### **Category-wise Budget Allocation:**")
        st.write(pd.DataFrame.from_dict(user_budget, orient="index", columns=["Budget (₹)"]))

        #Budget suggestion
        df['month'] = df['Date'].dt.strftime('%Y-%m') 
        category_monthly_spending = df.groupby(['Category', 'month'])['Amount'].sum().reset_index()
        category_avg_spending = category_monthly_spending.groupby('Category')['Amount'].mean().to_dict()
        

        st.subheader("💡 Budget Suggestions Based on Past Spending")

        for category, budget_value in user_budget.items():
            past_avg = category_avg_spending.get(category, 0)  # Get the correct average spending

            if budget_value > past_avg:
                suggestion = f"🔻 Decrease budget for '{category}', you usually spend ₹{past_avg:.2f}."
            elif budget_value < past_avg:
                suggestion = f" 🔼 Increase budget for '{category}', you usually spend ₹{past_avg:.2f}."
            else:
                suggestion = f"✅ Budget for '{category}' is well-planned."
            
            st.write(suggestion)

     

        # Create DataFrame for visualization
        budget_vs_spending = pd.DataFrame({
            "Category": list(user_budget.keys()),
            "User Budget": list(user_budget.values()),
            "Past Spending": [category_avg_spending .get(cat, 0) for cat in user_budget.keys()]
        })

        # Melt the DataFrame for easy plotting
        budget_vs_spending_melted = budget_vs_spending.melt(id_vars="Category", var_name="Type", value_name="Amount")

        st.subheader("📊 Budget vs. Actual Spending")

        fig = px.bar(
            budget_vs_spending_melted,
            x="Category",
            y="Amount",
            color="Type",
            barmode="group",
            text_auto=True,
            title="Budget vs. Actual Spending per Category"
        )

        st.plotly_chart(fig)

        # Calculate total spending
        total_actual_spending = sum(category_avg_spending.get(cat, 0) for cat in user_budget.keys())

        # Compare budget and actual spending
        st.subheader("📊 Financial Summary")

        if total_budget > total_actual_spending:
            st.success(f"🎉 Great job! You have saved ₹{total_budget - total_actual_spending:.2f} this month.")
        elif total_budget < total_actual_spending:
            st.error(f"⚠️ You have overspent by ₹{total_actual_spending - total_budget:.2f}! Consider adjusting your budget.")
        else:
            st.info("✅ Your spending matches your planned budget exactly!")

        # Identify Overspending Categories
        overspending_categories = {
            category: (user_budget[category], category_avg_spending[category])
            for category in user_budget.keys()
            if user_budget[category] < category_avg_spending.get(category, 0)
        }

        if overspending_categories:
            st.subheader("⚠️ Categories Where You Overspent")
            overspending_df = pd.DataFrame([
                {"Category": cat, "Budgeted (₹)": bud, "Spent (₹)": spent, "Difference (₹)": spent - bud}
                for cat, (bud, spent) in overspending_categories.items()
            ])
            st.dataframe(overspending_df)

        # Identify Savings in Categories
        savings_categories = {
            category: (user_budget[category], category_avg_spending[category])
            for category in user_budget.keys()
            if user_budget[category] > category_avg_spending.get(category, 0)
        }

        if savings_categories:
            st.subheader("💰 Categories Where You Saved")
            savings_df = pd.DataFrame([
                {"Category": cat, "Budgeted (₹)": bud, "Spent (₹)": spent, "Saved (₹)": bud - spent}
                for cat, (bud, spent) in savings_categories.items()
            ])
            st.dataframe(savings_df)




    # Budget Forecasting Tab
    with tab4:
        st.header("🔮 Budget Forecasting")
        st.write("Predict your future expenses using ML.")
        # Step 2: Preprocess Data
        df["Date"] = pd.to_datetime(df["Date"], format="%d-%m-%Y", dayfirst=True)
        df["Month"] = df["Date"].dt.to_period("M")  # Convert to monthly period format

        # Aggregate monthly spending
        monthly_expenses = df.groupby("Month")["Amount"].sum().reset_index()
        monthly_expenses["Month"] = monthly_expenses["Month"].astype(str)  # Convert to string for plotting

        st.subheader("📊 Past Monthly Expenses")
        st.line_chart(monthly_expenses.set_index("Month"))

        # Step 3: Fit ARIMA Model
        st.subheader("🔮 Forecasting Future Expenses")
        past_expense_series = monthly_expenses.set_index("Month")["Amount"]

        # Ensure ARIMA works with numeric index (convert months to range)
        past_expense_series.index = pd.RangeIndex(start=1, stop=len(past_expense_series) + 1, step=1)

        # Fit ARIMA model
        # Auto-select best ARIMA parameters
        best_model = auto_arima(past_expense_series, seasonal=False, stepwise=True, suppress_warnings=True)
        model_fit = best_model.fit(past_expense_series)
        # Forecast next 3 months
        forecast_steps = 3
        forecast_index = [f"Month {i}" for i in range(len(past_expense_series) + 1, len(past_expense_series) + forecast_steps + 1)]
        forecast_values = model_fit.forecast(steps=forecast_steps)

        # Step 4: Display Forecast Results
        forecast_df = pd.DataFrame({"Month": forecast_index, "Predicted Expense": forecast_values})
        st.write("📌 **Predicted Expenses for the Next 3 Months:**")
        st.dataframe(forecast_df)

        # Plot Forecast vs Actual Data
        plt.figure(figsize=(10, 5))
        plt.plot(past_expense_series.index, past_expense_series, marker="o", label="Actual Expense", color="blue")
        plt.plot(range(len(past_expense_series) + 1, len(past_expense_series) + forecast_steps + 1),
                forecast_values, marker="o", linestyle="dashed", label="Forecasted Expense", color="red")
        plt.xlabel("Month")
        plt.ylabel("Expense Amount (₹)")
        plt.title("Past & Forecasted Monthly Expenses")
        plt.legend()
        st.pyplot(plt)

